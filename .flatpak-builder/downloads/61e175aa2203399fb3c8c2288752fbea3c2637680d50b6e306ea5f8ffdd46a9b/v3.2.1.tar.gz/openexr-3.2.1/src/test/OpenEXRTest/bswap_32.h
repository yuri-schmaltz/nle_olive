//
// SPDX-License-Identifier: BSD-3-Clause
// Copyright (c) Contributors to the OpenEXR Project. See LICENSE file for details.
//

#if defined(_WIN32) || defined(_WIN64)
#    include <stdlib.h>
#    define bswap_32(x) _byteswap_ulong (x)
#elif defined(__APPLE__)
#    include <libkern/OSByteOrder.h>
#    define bswap_32(x) OSSwapInt32 (x)
#elif defined(__sun) || defined(sun)
#    include <sys/byteorder.h>
#    define bswap_32(x) BSWAP_32 (x)
#elif defined(__FreeBSD__)
#    include <sys/endian.h>
#    define bswap_32(x) bswap32 (x)
#elif defined(__OpenBSD__)
#    include <sys/types.h>
#    define bswap_32(x) swap32 (x)
#elif defined(__NetBSD__)
#    include <sys/bswap.h>
#    include <sys/types.h>
#    define bswap_32(x) bswap32 (x)
#else
#    include <byteswap.h>
#endif
